# VeloxG---backend
VeloxG is a lightweight, Python-powered semantic search engine designed to work both online and offline, optimized for African data like dictionaries, education content, locations, and more.
